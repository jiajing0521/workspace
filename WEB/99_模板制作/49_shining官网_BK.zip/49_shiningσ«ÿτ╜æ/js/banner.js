$(document).ready(function(){
	var num=$('.c_banner_span span').length;
	var i_mun=0;
	var timer_banner=null;

	$('.c_banner_ul li:gt(0)').hide();//页面加载隐藏所有的li 除了第一个
	
//底下小图标点击切换
	$('.c_banner_span span').click(function(){
		$(this).addClass('c_banner_span_one')
			   .siblings('span').removeClass('c_banner_span_one');
		var i_mun1=$('.c_banner_span span').index(this);
		$('.c_banner_ul li').eq(i_mun1).fadeIn('slow')
			                   .siblings('li').fadeOut('slow');

		i_mun=i_mun1;
	});
	
//左边箭头点击时切换
	$('.c_banner_left').click(function(){
		if(i_mun==0){
			i_mun=num
		}
		//大图切换
		$('.c_banner_ul li').eq(i_mun-1).fadeIn('slow')
								   .siblings('li').fadeOut('slow');
		//小图切换
		$('.c_banner_span span').eq(i_mun-1).addClass('c_banner_span_one')
				   .siblings('span').removeClass('c_banner_span_one');

		i_mun--
	});

	//左边按钮移动到其上时更换背景图片
    $('.c_banner_left').mouseover(function(){
		
		$('.c_banner_left').addClass('c_banner_left1');
	});

	//左边按钮移动到其上时还原背景图片
	$('.c_banner_left').mouseout(function(){
		
		$('.c_banner_left').removeClass('c_banner_left1');
	});

//右边箭头点击时切换
	$('.c_banner_right').click(function(){
		move_banner()
		
	});

	//右边按钮移动到其上时更换背景图片
	$('.c_banner_right').mouseover(function(){
		
		$('.c_banner_right').addClass('c_banner_right1');
	});

	//右边按钮移动到其上时更换背景图片
	$('.c_banner_right').mouseout(function(){
		
		$('.c_banner_right').removeClass('c_banner_right1');
	});
	
//鼠标移动到幻灯片上时 显示左右切换案例
	$('.c_banner').mouseover(function(){
		$('.c_banner_left').show();
		$('.c_banner_right').show();
	});

//鼠标离开幻灯片上时 隐藏左右切换案例
	$('.c_banner').mouseout(function(){
		$('.c_banner_left').hide();
		$('.c_banner_right').hide();
	});
	
	//自动播放函数
	function bannerMoveks(){
		timer_banner=setInterval(function(){
			move_banner()
		},2000)
	};
	bannerMoveks();//开始自动播放

	//鼠标移动到banner上时停止播放
	$('.c_banner').mouseover(function(){
		clearInterval(timer_banner);
	});

	//鼠标离开 banner 开启定时播放
	$('.c_banner').mouseout(function(){
		bannerMoveks();
	});


//banner 右边点击执行函数
   function move_banner(){
			if(i_mun==num-1){
				i_mun=-1
			}
			//大图切换
			$('.c_banner_ul li').eq(i_mun+1).fadeIn('slow')
									   .siblings('li').fadeOut('slow');
			//小图切换
			$('.c_banner_span span').eq(i_mun+1).addClass('c_banner_span_one')
					   .siblings('span').removeClass('c_banner_span_one');

			i_mun++
		
		}

})















