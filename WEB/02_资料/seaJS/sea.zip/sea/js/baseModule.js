/**
 * Created by dingjz on 2016/12/13.
 */
define(["myModule"], function (require, exports, module) {
    var per = require('myModule');
    module.exports = {
        sex: '男'
    }
});